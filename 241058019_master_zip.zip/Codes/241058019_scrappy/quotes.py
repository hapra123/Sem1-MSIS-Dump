class msisscraper(scrapy.Spider):
    name = "msisscraper"
    start_urls = ['https://www.flipkart.com/search?q=mobiles&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off']

    def parse(self, response):
        for flippy in response.css('div.tUxRFH'):
            yield {
                'product name': flippy.css('div.KzDlHZ::text').get(),
                'price': flippy.css('div.Nx9bqj._4b5DiR::text').get(),
                'discount': flippy.css('div.yRaY8j.ZYYwLA::text').get().strip() if flippy.css('div.yRaY8j.ZYYwLA::text').get() else None,  # Clean the discount text
                'description': flippy.css('div._6NESgJ ul.taG4BRas li.J+igdf::text').getall(),
                'image': flippy.css('img.DByuf4::attr(src)').get(),  # Extracting image link
            }
